import os
os.chdir("plugins")
os.chdir("scripts")

def READ():
	for i in listdir():
		print(i)
	app()
def OPEN():
	
	try:
		app_pl = input("open>> ")
		file = open(app_pl + ".csplug", "r")
		filet = file.read()
		file.close()
		eval(filet)
	except:
		print("plugin doesnt exist")
		app()
def app():
			user = input(">>")
			if user == "exit":
				quit()
			elif user == "read":
				READ()
			elif user == "open":
				OPEN()
			else:
				print("Write help for help.")
				app()
			
app()