from tkinter import *
from customtkinter import *
from tkinter import messagebox
from tkinter import filedialog
from tkinter import ttk
import requests
import os


anim_ws = 500
anim_hs = 100
app = CTk()
app.geometry("1920x1080")
app.title("NotePad")
global text
text = CTkTextbox(app, width=anim_ws,height=anim_hs, font=("Arial", 32))
icon = PhotoImage(file="img/cs_icon.png")
text.pack(expand=True)
os.chdir("plugins")
os.chdir("data")
try:
	from colortheme import light
	if light == True:
		set_appearance_mode("light")
	else:
		set_appearance_mode("dark")
	os.chdir("../..")
except:
	set_appearance_mode("dark")
	os.chdir("../..")
for anim in range(30):
	anim_ws += 20
	anim_hs += 20
	text.configure(height=anim_hs,width=anim_ws)
def save_file():
	try:
		file_s = filedialog.asksaveasfile(defaultextension='.txt',
		filetypes=[
		('Text File', '.txt'),
		("Python File", '.py'),
		("C, C++ File", ".c"),
		("XML Data File", ".xml"),
		("Json Data File", ".json"),
		("Website Language File", ".html"),
		("Website Style Language File", ".css"),
		("Javascript File", ".js"),
		("Java File", ".java"),
		("All Files", ".*")
		])
		text_boxt = text.get(1.0,END)
		file_s.write(text_boxt)
		file_s.close()
	except:
		messagebox.showerror(title="Error",message="Some Error Occurred during the app console.")
def open_file():
	try:
		text.delete(1.0, END)
		o_f=filedialog.askopenfilename()
		file = open(o_f, 'r')
		text_file = file.read()
		text.insert(INSERT, text_file)
	except:
		messagebox.showerror(title="Error",message="You selected the wrong file.")
def sizef():
	def set_fsize():
		try:
			text_f_c = float(text_f.get())
			font_s.destroy()
			text.configure(font=("Arial", text_f_c))
		except Exception:
			messagebox.showerror(title="Error",message="The entry is with characters or blank.")
	font_s = CTk()
	font_s.geometry("200x100")
	font_s.title("Edit Font Size")
	global text_f_n
	global text_f
	text_f_n = StringVar()
	text_f = CTkEntry(font_s, textvariable=text_f_n)
	text_f.pack()
	CTkButton(font_s, text="Apply", command=set_fsize).pack()
	font_s.mainloop()
def download_win():
	def download_plug():
		try:
			os.chdir("plugins")
			os.chdir("scripts")
			url3 = str(entryUrl.get())
			print('Getting Dowland Link..')
			response3 = requests.get(url3)
			print('Dowland link get!')
			filename_app = response3.url[url3.rfind('/')+1:]
			print('Installing file..')
			with open(filename_app, 'wb') as dowland_file:
					for chunk in response3.iter_content(chunk_size=8192):
						if chunk:
							dowland_file.write(chunk)
			messagebox.showinfo(title="Download Complete!", message="Downloaded without errors.")
			os.chdir('../..')
		except Exception as e:
			try:
				os.chdir('../../errors')
				messagebox.showerror(title="Error", message="An Error Occurred, check the errors dir for info.")
				file_err = open("Recent_Error.txt", 'w')
				file_err.write(str(e))
				file_err.close()
				dw.destroy()
			except Exception as e:
				messagebox.showerror(title="Error",message="Error Occurred and error writing error file too.")
				print(e)
				dw.destroy()
		
	dw = CTk()
	dw.geometry("400x200")
	dw.title('Download Plugin')
	CTkLabel(dw,text="Insert the plugin url, \nif you dont have it, you can copy \nit on the link: site\n or download it in the site.\n Its not recommended downloading other links files.").pack()
	global entryUrl
	global entryUrlT
	entryUrlT = StringVar()
	entryUrl = CTkEntry(dw, textvariable=entryUrlT)
	entryUrl.pack()
	CTkButton(dw,text="Apply", command=download_plug).pack()
	dw.mainloop()
bar = Menu(app)
app.config(menu=bar)
file = Menu(bar)
theme = Menu(bar)
CTkLabel(app,text="Credits to CrystalStudios ",image=icon).pack()
bar.add_cascade(label="File", menu=file)
file.add_command(label="Open", command=open_file)
file.add_command(label="Save", command=save_file)
file.add_separator()
file.add_command(label="Exit",command=quit)
bar.add_cascade(label="Theme", menu=theme)
theme.add_command(label="Font Size", command=sizef)
bar.add_command(label="Download Plugin", command=download_win)
app.mainloop()