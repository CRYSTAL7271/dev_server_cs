All this things are not own by Python.
By CrystalStudios.
-------------------------------
Ver: 1.0
System: PySystem  T1
Credits: Python, CrystalStudios.

How to:
If you want install this on android install PyDroid3 and some
modules like, colorama, sys(some of these are already installed), os, shutil, zipfile,
bs4, requests, time.

If you want to dowland it on pc, use or notepad++ or VsStudio. There are more but i dont know.
If you want to install the updates you have to go on the site.(and replace the system.py) 
(website link)
For the apps, you can install it in terminal using the !pkg_install.online_list, you'll see the online apps,
if you want to install it use, !pkg_install.online(in older systems you cannot dowland some apps)
There are offline apps too, you'll find it using, !pkg_install.local
If you want use a Archive for files, go on !storage.