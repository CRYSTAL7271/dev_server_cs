import sys
import time
import app_archive as apps
import data as dt
import requests
from requests.auth import HTTPBasicAuth
from bs4 import BeautifulSoup
try:
	import ccommands
	import data
except:
	print("Error:\n  You do not have data files>>\n. " + str(Exception))
	print('Start the Terminal in the Pybootsys, and then you can modify the system.')
	sys.exit()

print("Go search us in: pyter-online-official-cs.netlify.app/ Welcome to PyTerminal. If you need help write '!help'")
def system():
	user = input(">> ")
	
	if user == '!help':
		try:
			print("commands:")
			print('!search.updates, !stop_session, !pkg_install.local, pkg_install.online, !online_help, !info.sys, !pkg_see.data, !pkg_install.online_list')
			print("other commands:\n!fix_data.sys(this command has to be put in the bootsys, but it can reset or fix the data)")
			system()
		except Exception as e:
			print(e)
	elif user == '!pkg_install.local':
		try:
			print("Put the apps name(the apps name are in the site)")
			app_name = input("pkg_install>> ")
			if app_name == 'time':
				if dt.datetime_app == False:
					print("- searching for " + app_name + "..")
					time.sleep(0.7)
					print("-  App Found!")
					time.sleep(0.3)
					print("- This is a System Pkg App(SPA) so it'll modify the system.")
					time.sleep(0.9)
					print("-  Installing Fpack..")
					time.sleep(0.3)
					print("-   Installing) Spack..")
					time.sleep(0.2)
					print("-  Finishing dowlanding..")
					time.sleep(0.5)
					print("- Dowland Ended.")
					file_time = open("data.py", "a")
					file_time.write("datetime_app = True\n")
					sys.exit()
				else:
					print('"time" pkg already exists!')
					system()
			else:
				print('pkg doesnt exist.')
				system()
		except Exception as e:
			print()
	elif user == "!time":
		apps.rltime()
		system()
	elif user == '!info':
		print('Ver: 1.0\nSystem: PyTerminal\nType: Non-Gui\n For more info, see the PyTerminal.html!')
	elif user == '!online_help':
		try:
			print('Founding connection..')
			url = 'https://pyterminal-online-info.netlify.app/'
			ext = '.nc'
			response = requests.get(url)
			response_text = response.text
			print(response_text)
			time.sleep(0.1)
			system()
		except Exception as e:
			print('Error:\n')
			print(e)
			system()
	elif user == '!search.updates':
		try:
			print('Founding Connection..')
			url1 = 'https://pyterminal-online-infoupdates.netlify.app/'
			ext1 = '.nc'
			response1 = requests.get(url1)
			response_text1 = response1.text
			print(response_text1)
			system()
		except Exception as e:
			print('Error:\n' + str(e))
			system()
	elif user == '!pkg_install.online_list':
		try:
			print('Founding Connection..')
			url2 = 'https://pystore-terminal-online-apps.netlify.app/'
			ext2 = '.nc'
			response2 = requests.get(url2)
			response_text2 = response2.text
			print(response_text2)
			system()
		except Exception as e:
			print('Error\n ' + e)
	elif user == '!pkg_install.online':
		try:
			downl_inp = input('pkg_install.online>> ')
			if downl_inp == 'PyFiles':
				url3 = 'https://pystore-terminal-online-apps.netlify.app/storage_app.py'
				print('Getting Dowland Link..')
				response3 = requests.get(url3)
				print('Dowland link get!')
				filename_app = response3.url[url3.rfind('/')+1:]
				print('Installing file..')
				with open(filename_app, 'wb') as dowland_file:
					for chunk in response3.iter_content(chunk_size=8192):
						if chunk:
							print('Almost finish.')
							dowland_file.write(chunk)
							dowland_file.close()
							print('file dowlanded.')
							system()
			else:
				print('pkg doesnt exists!')
				system()
		except Exception as e:
			print('Error:\n' + str(e))
			system()
	elif user == '!storage':
		apps.storage_file()				
	elif user == '!stop_session':
		sys.exit('Stopped Session')
		
	else:
		print("PyTerminal Traceback>>\n. Error detected in system.py:\n.   " + user + " is not definded.\n InputError.")
		system()
system()
