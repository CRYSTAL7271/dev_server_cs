import time
import sys
def systemb():
	print("loading..")
	time.sleep(0.35)
	print("- BootSys loaded.")
	userb = input()
	
	if userb == '!fix_data.sys':
		print("fixing..")
		time.sleep(1.5)
		file1 = open("data.py", "w")
		file1.write('datetime_app = False')
		file1.close()
		print("data.py Created. Wait..")
		time.sleep(1.2)
		file2 = open("ccommands.py", "w")
		file2.close()
		print("All data system files created or fixed. bootsys.py is closing..")
		time.sleep(2)
		sys.exit()
	else:
		print("InputError: Str_comm not avaiable-.")
		systemb()
systemb()	