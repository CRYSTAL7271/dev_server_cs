import colorama
import time
import datetime
import sys
import data as dt
def rltime():
	try:
		if dt.datetime_app == True:
			print(time.strftime("Time: %H:%M:%S, Date: %y/%m/%d"))
		else:
			print("This command is not avaiable because you didnt installed the time pkg.")
	except Exception as e:
		print("This command is not avaiable because you didnt installed the time pkg. PyError: " + str(e))
		
def storage_file():
	try:
		import storage_app
	except ImportError as e:
		print("This pkg is not avaiable because you didnt installed the PyFiles pkg, this pack is online so you have to dowland it with !pkg_install.online. PyError: " + str(e))
		
			