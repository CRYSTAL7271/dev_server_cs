from pygame import mixer
from pygame import *
from tkinter import *
from tkinter import messagebox
import os
import shutil
import time
mixer.init()
def hai_perso():
	time.sleep(3)
	start_j.destroy()
	lose = Tk()
	lose.geometry()
	lose.title("Hai Perso - Chiudi la finestra per finire.")
	losed = PhotoImage(file="lose.png")
	Label(lose, image=losed).pack()
	os.chdir('..')
	os.remove('secret1_alessino.txt')
	os.remove('jump.png')
	lose.mainloop()
def alessino_pazzparla():
	messagebox.showinfo(title="Alessino.exe", message="COSA TI HO DETTO?!")
	messagebox.showinfo(title="Alessino.exe", message="Sai cosa!?")
	messagebox.showinfo(title="Alessino.exe", message="Resettero il programma.")
	messagebox.showinfo(title="Alessino.exe", message="Addio.")
	os.chdir("data")
	os.remove("data_open.csdata")
	quit()
def pazzino():
	start_pazz = Tk()
	start_pazz.geometry("1280x720")
	start_pazz.title("Bastaaaa BIIIIIII")
	mixer.music.load("urlo.mp3")
	mixer.music.play()
	alessino_pazz = PhotoImage(file="jump.png")
	Label(start_pazz,image=alessino_pazz).pack()
	alessino_pazzparla()
	start_pazz.mainloop()
def alessino_jump():
		global start_j
		os.chdir('Alessino_Robux')
		start_j = Tk()
		mixer.music.play()
		start_j.geometry("720x720")
		time.sleep(0.1)
		alessino_j = PhotoImage(file="jump.png")
		Label(master=start_j, image=alessino_j).pack()
		hai_perso()
		start_j.mainloop()
def continue1():
	messagebox.showinfo(title="Alessino.exe", message="Bravo.")
	os.remove("jump.png")
	messagebox.showinfo(title="Alessino.exe", message="Ti farò un regalino.")
	os.chdir('Alessino_Robux')
	file_secret1 = open('project1.py', 'w')
	file_secret1.write("date='19:30 May 2012'\ndanger=7\nname='Alessino Normal'\ninfo='''Alessino Normal. È la prima versione di Alessino.\nÈ consigliato dargli i croccantini,\nsennò può impazzire veramente troppo.\nPultroppo Crystal e stato bloccato da una delle sue abilità, e quindi esso è bloccato.\nAbilità:Blocco Forzato, può bloccare tutte le persone ha causa delle sue puzzette.''' ")
		
	file_secret1.close()
	messagebox.showinfo(title="Alessino.exe", message="Ho creato un file sul tuo computer")
	messagebox.showinfo(title="Alessino.exe", message="Adesso, puoi andare. E non aprirmi più")
	os.chdir("data")
	if os.path.exists('data_open.py') == True:
		pass
	else:
		data_open=open('data_open.csdata',"w")
		data_open.write('CrystalStudios Data File:\n  mainpyfile coded by CrystalStudios.\n  DataFileInfo: When re-open mainpy it will be reset by Alessino')
def start_talk():
	messagebox.showinfo(title="Alessino.exe", message="Bene, bene, bene...")
	name = os.getlogin()
	messagebox.showinfo(title="Alessino.exe", message="Ti vorrei vedere... " + str(name))
	start.destroy()
	time.sleep(1)
	#start.destroy()
	messagebox.showerror(title="Errore", message="Accesso alla telecamera rifiutato.")
	messagebox.showinfo(title="Alessino.exe", message="Cavolo...")
	messagebox.showinfo(title="Alessino.exe", message="Vabbe, ci proverò un'altra volta..")
	time.sleep(2)
	messagebox.showinfo(title="Alessino.exe", message="Perchè non facciamo un gioco..?")
	messagebox.showinfo(title="Alessino.exe", message="Cerca il file nel tuo sistema entro un minuto.")
	accepted = False
	while not accepted:
		if messagebox.askyesno(title="Alessino.exe", message="Che ne dici?") == True:
			accepted = True
			messagebox.showinfo(title="Alessino.exe", message="Bene... (premi ok per iniziare)")
			os.chdir("..")
			file_1 = open("secret1_alessino.txt", "w")
			file_1.write("Alessino\nti\nguarda..")
			file_1.close()
			counter = 0
			while True:
				time.sleep(1)
				counter += 1
				try:
					file_1c = open("secret1_alessino.txt", "r")
					file_1c.close()
					file_check = True
				except:
					file_check = False
				if counter > 20:
					alessino_jump()
					break
				elif file_check == False:
					continue1()
					break
		else:
			mixer.music.play()
def alessino_start():
	if messagebox.askyesno(title="Inizio Gioco", message="Se vuoi uscire premi no, invece se vuoi uscire nel \nmentre che sei in gioco basta che vai nella gestione attività del pc è toglierlo forzatamente, \n (dovrai rifare il gioco)") == True:
		shutil.copy('jump.png', '../jump.png')
		global start
		start = Tk()
		mixer.music.load('urlo.mp3')
		mixer.music.play()
		start.geometry("1280x720")
		time.sleep(0.1)
		alessino_start = PhotoImage(file="start.png")
		Label(start, image=alessino_start).pack()
		time.sleep(4)
		start_talk()
		start.mainloop()
	else:
		pass
if os.path.exists('data//data_open.csdata')==True:
	pazzino()
else:
	alessino_start()
