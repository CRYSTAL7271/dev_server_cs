
import os
print('Scrivi help per una mano. Demo')
def start():
	user = input('>> ')
	if user == 'help':
		print('help: open_csdoc')
		start()
	elif user == 'open_csdoc':
		try:
			from project1 import name,danger,date,info
		except:
			print('Document not found')
		try:
			print(name,'\ndanger: ',danger, '\ndate: ',date,'\n\n',info)
			start()
		except Exception as e:
			print('Error  > ' + e)
			start()
	elif user == 'exit':
		input('[press Enter to exit]')
	else:
		start()
start()