
import os
print('Scrivi help per una mano. Demo')
def start():
	user = input('>> ')
	if user == 'help':
		print('help: open_csdoc')
		start()
	elif user == 'open_csdoc':
		try:
			from project1 import name,danger,date,info
			print(name,'\ndanger: ',danger, '\ndate: ',date,'\n\n',info)
			start()
		except ModuleNotFoundError as e:
			print('No modules: ' + e)
			start()
	else:
		start()
start()