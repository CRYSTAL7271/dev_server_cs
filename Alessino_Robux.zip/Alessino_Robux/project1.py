date='19:30 May 2012'
danger=7
name='Alessino Normal'
info='''Alessino Normal. È la prima versione di Alessino.
È consigliato dargli i croccantini,
sennò può impazzire veramente troppo.
Pultroppo Crystal e stato bloccato da una delle sue abilità, e quindi esso è bloccato.
Abilità:Blocco Forzato, può bloccare tutte le persone ha causa delle sue puzzette.''' 